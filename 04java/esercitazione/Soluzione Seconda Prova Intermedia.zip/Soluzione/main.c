#include<stdio.h>
#include<stdlib.h>

int conta_strings(char **v, int size);

int conta(char *s);

int main(int argc, char **argv)
{
    if (argc != 7) {
        printf("Wrong input parameters\n");
        exit(1);
    }
    int test1 = atoi(argv[1]);
    int test2 = atoi(argv[2]);
    int test3 = atoi(argv[3]);
    int test4 = atoi(argv[4]);
    int test5 = atoi(argv[5]);
    int test6 = atoi(argv[6]);

    if (test1 == 1) {
        char s1[8] = "abdefhu";
        int res = conta(s1);
        if (res == 3) {
            printf("Test 1: risultato -> %d == 3 -> OK!\n\n", res);
        }
        else {
            printf("Test 1: risultato -> %d != 3 -> Error!\n\n", res);
        }
    }
    if (test2 == 1) {
        char s1[1] = "";
        int res = conta(s1);
        if (res == 0) {
            printf("Test 2: risultato -> %d == 0 -> OK!\n\n", res);
        }
        else {
            printf("Test 2: risultato -> %d != 0 -> Error!\n\n", res);
        }
    }
    if (test3 == 1) {
        char *s1 = NULL;
        int res = conta(s1);
        if (res == 0) {
            printf("Test 3: risultato -> %d == 0 -> OK!\n\n", res);
        }
        else {
            printf("Test 3: risultato -> %d != 0 -> Error!\n\n", res);
        }
    }
    if (test4 == 1) {
        char **v = (char **) malloc(sizeof(char *) * 3);
        char s1[8] = "abdefhu";
        char s2[6] = "HJdfg";
        char s3[9] = "aerdswxz";
        v[0] = s1; v[1] = s2; v[2] = s3;
        int res = conta_strings(v, 3);
        if (res == 5) {
            printf("Test 4: risultato -> %d == 5 -> OK!\n\n", res);
        }
        else {
            printf("Test 4: Risultato -> %d != 5 -> Error!\n\n", res);
        }
    }
    if (test5 == 1) {
        char **v = (char **) malloc(sizeof(char *) * 2);
        char s1[1] = "";
        char s2[8] = "abdefhu";
        v[0] = s1; v[1] = s2;
        int res = conta_strings(v, 2);
        if (res == 3) {
            printf("Test 5: risultato -> %d == 3 -> OK!\n\n", res);
        }
        else {
            printf("Test 5: Risultato-> %d != 3 -> Error!\n\n", res);
        }
    }
    if (test6 == 1) {
        char **v = NULL;
        int res = conta_strings(v, 0);
        if (res == 0) {
            printf("Test 6: risultato -> %d == 0 -> OK!\n\n", res);
        }
        else {
            printf("Test 6: Risultato-> %d != 0 -> Error!\n\n", res);
        }
    }
    return 0;
}
